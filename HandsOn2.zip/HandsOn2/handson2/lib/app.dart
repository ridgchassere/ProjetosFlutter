import 'package:flutter/material.dart';
import 'package:handson2/paginas/home.dart';
import 'package:handson2/paginas/segundapagina.dart';


class App extends StatelessWidget{
  const App({super.key});
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      home: const HomePage(),
      routes:{
        '/home':(context)=>const HomePage(),
        '/segunda':(context)=> SecondPage(),
      },
    );
  }
}