import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        
        title: const Text(
          'Home Page',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children:[
        Text("listagem e navegação",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 20)),
        Text("\numa aplicação para\ngerencia de estado e\nnavegação com Flutter"),
        SizedBox(height: 10),
        ElevatedButton(
               

              
              onPressed: () {
                
                Navigator.pushNamed(context, '/segunda');
              },
              child:
              
              const Text('ir para list page',style: TextStyle(
            color: Colors.white,
          ),),

              style: ElevatedButton.styleFrom(backgroundColor:Colors.red),

             
              )
          ]
      ),
      ),
    );
  }

}
