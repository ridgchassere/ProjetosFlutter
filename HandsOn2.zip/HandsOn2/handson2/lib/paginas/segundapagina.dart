

import 'package:flutter/material.dart';


int count=0;

class SecondPage extends StatefulWidget {
  

  @override
  _SecondPageState createState() => _SecondPageState();
}

class _SecondPageState extends State<SecondPage> {
  List<dynawidge> listda = [];


  


  adici(){
    listda.add(dynawidge());
    
    setState(() {
      
    });

  


  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: new Scaffold(
      appBar: AppBar(
        centerTitle: true,
        
        title: const Text(
          'list page',
          style: TextStyle(
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.red,
      ),
      body: Center(
        child: Column(
          
          mainAxisAlignment: MainAxisAlignment.center,
          children:<Widget> [
            new Flexible(child: new ListView.builder(
                itemCount: listda.length,
                itemBuilder:(_,index)=>listda[index] ,)
                ),
            
            ElevatedButton(
              onPressed: () {
                count+=1;

                adici();


                setState(() {


                  ;
                  
                
                  
                 

                });
              },
              child: const Text('adicionar item',style: TextStyle(
            color: Colors.white,
          ),),

              style: ElevatedButton.styleFrom(backgroundColor:Colors.red),),
            
            SizedBox(height: 10),
            ElevatedButton(
               

              
              onPressed: () {
                count=0;
                Navigator.pushNamed(context, '/home');
              },
              child:
              
              const Text('voltar para Home',style: TextStyle(
            color: Colors.white,
          ),),

              style: ElevatedButton.styleFrom(backgroundColor:Colors.red),

             
              )
          ],

        ),
      ),
    ));
  }
}
        
      
         

  
class dynawidge extends StatelessWidget {
  @override
  Widget build(BuildContext context){
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
            border: Border.all(color: Colors.red),
            borderRadius: BorderRadius.circular(20)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('Item ${count}'),
            
            ElevatedButton(
              onPressed:null,
              

              
              
            
             child: Icon(Icons.delete)),
          ],
        ),
      ),
    );
  }
}